package com.gupaoedu.vip.mall.goods.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gupaoedu.vip.mall.goods.model.Brand;

/*****
 * @Author: 波波
 * @Description: 咕泡云商城
 ****/
public interface BrandMapper extends BaseMapper<Brand> {
}
